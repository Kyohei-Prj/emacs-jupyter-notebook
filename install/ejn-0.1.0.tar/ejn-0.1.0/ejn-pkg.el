;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejn" "0.1.0"
  "Emacs Jupyter Notebook."
  '((emacs "24.1"))
  :url "https://github.com/emacs-jupyter-notebook/emacs-jupyter-notebook"
  :keywords '("jupyter" "notebook" "tools" "convenience"))
